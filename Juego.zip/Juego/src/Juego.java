import java.util.Scanner;
import java.lang.Math;

public class Juego {

    private Tablero tablero;
    private Jugador jugador;
    private Scanner scanner;

    public Juego() {

        tablero = new Tablero(5);
        jugador = new Jugador();
        scanner = new Scanner(System.in);
    }

    public void iniciar() {

        boolean jugando = true;

        while (jugando) {

            tablero.mostrar(jugador);

            System.out.println("Puntaje: " + jugador.getPuntaje());

            System.out.println("Mover:");
            System.out.println("W = arriba");
            System.out.println("S = abajo");
            System.out.println("A = izquierda");
            System.out.println("D = derecha");

            String opcion = scanner.nextLine().toUpperCase();

            int nuevaFila = jugador.getFila();
            int nuevaColumna = jugador.getColumna();

            switch (opcion) {

                case "W":
                    nuevaFila--;
                    break;

                case "S":
                    nuevaFila++;
                    break;

                case "A":
                    nuevaColumna--;
                    break;

                case "D":
                    nuevaColumna++;
                    break;

                default:
                    System.out.println("Movimiento inválido");
                    continue;
            }

            // Uso obligatorio de Math
            int distancia = Math.abs(nuevaFila - jugador.getFila())
                    + Math.abs(nuevaColumna - jugador.getColumna());

            if (distancia != 1) {
                System.out.println("No se permiten diagonales");
                continue;
            }

            if (nuevaFila < 0 || nuevaFila >= tablero.getTamanio()
                    || nuevaColumna < 0 || nuevaColumna >= tablero.getTamanio()) {

                System.out.println("Fuera de límites");
                continue;
            }

            jugador.mover(nuevaFila, nuevaColumna);

            Celda actual = tablero.getCelda(nuevaFila, nuevaColumna);

            switch (actual.getTipo()) {

                case POTENCIADOR:
                    jugador.duplicarPuntaje();
                    System.out.println("Potenciador activado");
                    break;

                case MODIFICADOR:
                    jugador.sumarPuntos(50);
                    System.out.println("Modificador activado");
                    break;

                case OBJETIVO:
                    System.out.println("Llegaste al objetivo");
                    jugando = false;
                    break;
            }
        }

        System.out.println("Puntaje final: " + jugador.getPuntaje());
    }
}