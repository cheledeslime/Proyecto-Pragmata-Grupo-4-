import java.util.Random;

public class Tablero {

    // Celdas Pragmata
    private Celda[][] grilla;
    private int tamanio;

    public Tablero(int tamanio) {

        this.tamanio = tamanio;
        grilla = new Celda[tamanio][tamanio];

        inicializar();
    }

    private void inicializar() {

        for (int i = 0; i < tamanio; i++) {
            for (int j = 0; j < tamanio; j++) {

                grilla[i][j] = new Celda(i, j, TipoCelda.NORMAL);
            }
        }

        Random random = new Random();

        // Objetivo
        int fObj = random.nextInt(tamanio);
        int cObj = random.nextInt(tamanio);

        while (fObj == 0 && cObj == 0) {
            fObj = random.nextInt(tamanio);
            cObj = random.nextInt(tamanio);
        }

        grilla[fObj][cObj].setTipo(TipoCelda.OBJETIVO);

        // Potenciador
        int fPot = random.nextInt(tamanio);
        int cPot = random.nextInt(tamanio);

        while (grilla[fPot][cPot].getTipo() != TipoCelda.NORMAL ||
                (fPot == 0 && cPot == 0)) {

            fPot = random.nextInt(tamanio);
            cPot = random.nextInt(tamanio);
        }

        grilla[fPot][cPot].setTipo(TipoCelda.POTENCIADOR);

        // Modificador
        int fMod = random.nextInt(tamanio);
        int cMod = random.nextInt(tamanio);

        while (grilla[fMod][cMod].getTipo() != TipoCelda.NORMAL ||
                (fMod == 0 && cMod == 0)) {

            fMod = random.nextInt(tamanio);
            cMod = random.nextInt(tamanio);
        }

        grilla[fMod][cMod].setTipo(TipoCelda.MODIFICADOR);
    }

    public void mostrar(Jugador jugador) {

        // Movimientos omnidireccionales

        for (int i = 0; i < tamanio; i++) {

            for (int j = 0; j < tamanio; j++) {

                if (jugador.getFila() == i &&
                        jugador.getColumna() == j) {

                    System.out.print("[J] ");
                }
                else {

                    switch (grilla[i][j].getTipo()) {

                        case NORMAL:
                            System.out.print("[ ] ");
                            break;

                        case OBJETIVO:
                            System.out.print("[O] ");
                            break;

                        case POTENCIADOR:
                            System.out.print("[P] ");
                            break;

                        case MODIFICADOR:
                            System.out.print("[M] ");
                            break;
                    }
                }
            }

            System.out.println();
        }
    }

    public Celda getCelda(int fila, int columna) {
        return grilla[fila][columna];
    }

    public int getTamanio() {
        return tamanio;
    }
}